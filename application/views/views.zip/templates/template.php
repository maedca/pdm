<?php


$this->load->view('templates/front_end/header');
$this->load->view('templates/front_end/nav');
$this->load->view('front_end/'.$contenido);
$this->load->view('templates/front_end/footer');