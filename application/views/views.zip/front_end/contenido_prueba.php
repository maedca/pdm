
<header id="page-top">
    <div class="container ">
        <div class="row">
            <div class="col-lg-12">

                <div class="intro-text">
                    <span class="name">Terce's Designs</span>
                    <span class="icon-font glyphicon glyphicon-star"></span><br>
                    <hr>
                    <br><br>
                    <span class="skills tres-em">Dise�o y Calidad - Nacidos para estar juntos</span>
                </div>
            </div>
        </div>
    </div>
</header>


<section id="portfolio">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>Portfolio</h2>
                <span class="icon-font glyphicon glyphicon-star"></span><br>
                <hr><br><br>

            </div>
        </div>
        <div class="row">
            <div class="col-sm-4 portfolio-item">
                <a href="#portfolioModal1" class="portfolio-link" data-toggle="modal">
                    <div class="caption">
                        <div class="caption-content">
                            <i class="icon-font glyphicon glyphicon-zoom-in"></i>
                        </div>
                    </div>
                    <img src="<?php echo base_url('assets/images/cabin.png'); ?>" class="img-responsive" alt="">
                </a>
            </div>
            <div class="col-sm-4 portfolio-item">
                <a href="#portfolioModal2" class="portfolio-link" data-toggle="modal">
                    <div class="caption">
                        <div class="caption-content">
                            <i class="icon-font glyphicon glyphicon-zoom-in"></i>
                        </div>
                    </div>
                    <img src="<?php echo base_url('assets/images/cake.png'); ?>" class="img-responsive" alt="">
                </a>
            </div>
            <div class="col-sm-4 portfolio-item">
                <a href="#portfolioModal3" class="portfolio-link" data-toggle="modal">
                    <div class="caption">
                        <div class="caption-content">
                            <i class="icon-font glyphicon glyphicon-zoom-in"></i>
                        </div>
                    </div>
                    <img src="<?php echo base_url('assets/images/circus.png'); ?>" class="img-responsive" alt="">
                </a>
            </div>
            <div class="col-sm-4 portfolio-item">
                <a href="#portfolioModal4" class="portfolio-link" data-toggle="modal">
                    <div class="caption">
                        <div class="caption-content">
                            <i class="icon-font glyphicon glyphicon-zoom-in"></i>
                        </div>
                    </div>
                    <img src="<?php echo base_url('assets/images/game.png'); ?>" class="img-responsive" alt="">
                </a>
            </div>
            <div class="col-sm-4 portfolio-item">
                <a href="#portfolioModal5" class="portfolio-link" data-toggle="modal">
                    <div class="caption">
                        <div class="caption-content">
                            <i class=" icon-font glyphicon glyphicon-zoom-in"></i>
                        </div>
                    </div>
                    <img src="<?php echo base_url('assets/images/safe.png'); ?>" class="img-responsive" alt="">
                </a>
            </div>
            <div class="col-sm-4 portfolio-item">
                <a href="#portfolioModal6" class="portfolio-link" data-toggle="modal">
                    <div class="caption">
                        <div class="caption-content">
                            <i class="icon-font glyphicon glyphicon-zoom-in"></i>
                        </div>
                    </div>
                    <img src="<?php echo base_url('assets/images/submarine.png'); ?>" class="img-responsive" alt="">
                </a>
            </div>
        </div>
    </div>
</section>


<!-- <section class="success" id="about">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>About</h2>
                <span class="icon-font glyphicon glyphicon-star"></span><br><hr><br><br>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-lg-offset-2 text-justify">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem consequatur delectus est eveniet qui? Assumenda, at autem commodi consectetur culpa deserunt dignissimos doloribus eligendi impedit minima natus necessitatibus, quaerat, veritatis!</p>
            </div>
            <div class="col-lg-4 text-justify">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci atque commodi doloremque enim eum eveniet fuga harum inventore ipsum itaque iusto laborum molestiae quasi quia quo recusandae, saepe, ut voluptates.</p>
            </div><br><br>
            <div class="col-lg-8 col-lg-offset-2 text-justify">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur atque deserunt eum molestias nihil pariatur possimus recusandae saepe similique sit? Beatae cum delectus dolorem eaque excepturi facilis fuga natus odio?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid autem iure iusto magni repellendus vel! A, aspernatur beatae dolorem ea expedita id ipsam nam numquam officia, quam, velit vitae voluptatem!Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis cumque, error porro reprehenderit tempora veniam vero voluptas. Adipisci cum eos eum facilis fuga praesentium quaerat, quis quos recusandae sunt voluptatum.</p>
            </div>
        </div>
    </div>
</section> -->


<section id="contact">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>Contact Me</h2>
                <span class="icon-font glyphicon glyphicon-star"></span><br><br>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
                <form name="sentMessage" id="contactForm" novalidate>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                            <label>Name</label>
                            <input type="text" class="form-control" placeholder="Name" id="name">
                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                            <label>Email Address</label>
                            <input type="email" class="form-control" placeholder="Email Address" id="email">
                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                            <label>Phone Number</label>
                            <input type="tel" class="form-control" placeholder="Phone Number" id="phone" >
                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                            <label>Message</label>
                            <textarea rows="5" class="form-control" placeholder="Message" id="message"></textarea>
                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <br>
                    <div id="success"></div>
                    <div class="row">
                        <div class="form-group col-xs-12">
                            <button type="submit" class="btn btn-success btn-lg">Send</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>


<footer class="text-center">
    <div class="footer-above">
        <div class="container">
            <div class="row">
                <div class="footer-col col-md-4">
                    <h3>Location</h3>
                    <p>Anzoategui - Venezuela</p>
                    <p>Cubrimos en Area de la Ciudades de El Tigre y El Tigrito</p>
                    <p>Proyectos a nivel nacional e internacional a travez de nuestra <a href="tercesdesigns.com.ve">pagina web</a>.</p>
                </div>
                <div class="footer-col col-md-4">
                    <h3>Around the Web</h3>


                   <!-- <ul class="list-inline">
                        <li>
                            <a href="#" class="btn-social btn-outline"><i class=" glyphicon glyphicon-star"></i></a>
                        </li>
                        <li>
                            <a href="#" class="btn-social btn-outline"><i class=" glyphicon glyphicon-star"></i></a>
                        </li>
                        <li>
                            <a href="#" class="btn-social btn-outline"><i class=" glyphicon glyphicon-star"></i></a>
                        </li>

                    </ul> -->
                </div>
                <div class="footer-col col-md-4">
                    <h3>Additional</h3>
                    <p>La pagina actualmente esta en construccion, para dudas eh informacion no dudes en llenar nuestro formulario de
                        <a href="#contact">Contacto</a></p>
            </div>
        </div>
    </div>
    <div class="footer-below">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    Copyright &copy; Terce's Designs Website 2015
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-lg-offset-8">
                   Formated by <a href="http://www.tercesdesigns.com.ve">Terce</a> with <a href="http://getbootstrap.com">Bootstrap</a> and <a href="http://startbootstrap.com">Freelancer</a>
                    <br>
                    License <a href="http://www.apache.org/licenses/LICENSE-2.0">Apache 2.0</a>
                </div>
            </div>
        </div>
    </div>
</footer>


<div class="scroll-top page-scroll visible-xs visible-sm">
    <a class="btn btn-primary" href="#page-top">
        <i class="fa fa-chevron-up"></i>
    </a>
</div>


<div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-content">
        <div class="close-modal" data-dismiss="modal">
            <div class="lr">
                <div class="rl">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="modal-body">
                        <h2>Page Title / Description</h2><br>
                        <span class="icon-font glyphicon glyphicon-star"></span><br><hr><br><br>

                        <img src="<?php echo base_url('assets/images/cabin.png'); ?>" class="img-responsive img-centered" alt="">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet aspernatur atque blanditiis consequuntur dignissimos id in magnam maiores maxime officia, officiis perspiciatis possimus provident qui quis quisquam rerum tempora ut.</p>

                        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-zoom-out"></span> Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-content">
        <div class="close-modal" data-dismiss="modal">
            <div class="lr">
                <div class="rl">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="modal-body">
                        <h2>Page Title / Description</h2>
                        <span class="icon-font glyphicon glyphicon-star"></span><br><hr><br><br>
                        <img src="<?php echo base_url('assets/images/cake.png'); ?>" class="img-responsive img-centered" alt="">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam amet culpa dicta dolor doloremque dolorum eligendi fugit omnis saepe vero. A cumque explicabo facere modi praesentium quasi quis quisquam rerum.</p>

                        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-zoom-out"> Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-content">
        <div class="close-modal" data-dismiss="modal">
            <div class="lr">
                <div class="rl">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="modal-body">
                        <h2>Page Title / Description</h2>
                        <span class="icon-font glyphicon glyphicon-star"></span><br><hr><br><br>
                        <img src="<?php echo base_url('assets/images/circus.png'); ?>" class="img-responsive img-centered" alt="">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam cupiditate dicta distinctio dolor enim exercitationem fugit illo ipsum maiores nihil non, obcaecati optio quidem sapiente tenetur vero vitae voluptate voluptates.</p>

                        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-zoom-out"></span> Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-content">
        <div class="close-modal" data-dismiss="modal">
            <div class="lr">
                <div class="rl">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="modal-body">
                        <h2>Page Title / Description</h2>
                        <span class="icon-font glyphicon glyphicon-star"></span><br><hr><br><br>
                        <img src="<?php echo base_url('assets/images/game.png'); ?>" class="img-responsive img-centered" alt="">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium amet atque autem dolorum ducimus enim eum illo in inventore molestias neque, nostrum omnis quaerat quo sint tenetur veniam vitae voluptatem!</p>
                        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-zoom-out"></span> Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-content">
        <div class="close-modal" data-dismiss="modal">
            <div class="lr">
                <div class="rl">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="modal-body">
                        <h2>Page Title / Description</h2>
                        <span class="icon-font glyphicon glyphicon-star"></span><br><hr><br><br>
                        <img src="<?php echo base_url('assets/images/safe.png'); ?>" class="img-responsive img-centered" alt="">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis illo odio quibusdam sint. Beatae consequatur consequuntur dolore enim magni nesciunt non quam qui quibusdam ratione reiciendis rerum saepe sapiente, ut.</p>
                        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-zoom-out"></span> Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-content">
        <div class="close-modal" data-dismiss="modal">
            <div class="lr">
                <div class="rl">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="modal-body">
                        <h2>Page Title / Description</h2>
                        <span class="icon-font glyphicon glyphicon-star"></span><br><hr><br><br>
                        <img src="<?php echo base_url('assets/images/submarine.png'); ?>" class="img-responsive img-centered" alt="">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorem doloribus in numquam? Aperiam assumenda autem, delectus esse iure maiores, natus neque quaerat quasi reiciendis totam vel voluptate. Libero optio, tempora.</p>
                        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-zoom-out"></span> Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>